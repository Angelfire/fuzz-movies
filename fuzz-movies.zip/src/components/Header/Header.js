import React from 'react';

import './header.css';

const Header = () => {
  return (
    <h1 className="movuzz-header">Movuzz</h1>
  );
};

export default Header;
