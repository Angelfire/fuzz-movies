export const TMDB_API_KEY = '2b0769159b47f38c19956c012c6346bb';
export const TMDB_IMAGE_URL = 'https://image.tmdb.org/t/p/w185_and_h278_bestv2';
export const TMDB_MOVIE = 'https://api.themoviedb.org/3/search/movie';
export const TMDB_MOVIE_DETAILS = 'https://api.themoviedb.org/3/movie/';
